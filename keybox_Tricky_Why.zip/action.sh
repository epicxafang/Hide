#!/system/bin/sh

RAW_URL="https://raw.githubusercontent.com/Yurii0307/yurikey/main/key"
PROXIES="https://ghproxy.net/ https://mirror.ghproxy.com/ https://gh-proxy.com/ https://ghproxy.org/"
TARGET_DIR="/data/adb/tricky_store"
TARGET_FILE="$TARGET_DIR/keybox.xml"

if [ ! -d "$TARGET_DIR" ]; then
    echo "目录 $TARGET_DIR 不存在，请先安装 Tricky Store"
    sleep 5
    exit 1
fi

echo "正在从远程获取最新keybox..."

NEW_CONTENT=""
for PROXY in $PROXIES; do
    NEW_CONTENT=$(curl -k -sL --connect-timeout 8 "${PROXY}${RAW_URL}" | base64 -d 2>/dev/null)
    [ -n "$NEW_CONTENT" ] && break
    echo "代理 ${PROXY} 尝试失败"
done

if [ -z "$NEW_CONTENT" ]; then
    echo "所有代理均失效"
    sleep 5
    exit 1
fi

if [ ! -f "$TARGET_FILE" ]; then
    echo "原无keybox，已替换为模块获取的keybox"
    echo "$NEW_CONTENT" > "$TARGET_FILE"
else
    NEW_HASH=$(echo "$NEW_CONTENT" | sha256sum | cut -d' ' -f1)
    OLD_HASH=$(sha256sum "$TARGET_FILE" | cut -d' ' -f1)

    if [ "$NEW_HASH" = "$OLD_HASH" ]; then
        echo "当前keybox已是模块获取的最新keybox"
    else
        echo "已替换为模块获取的keybox，原keybox已备份为 ${TARGET_FILE}.1"
        mv "$TARGET_FILE" "${TARGET_FILE}.1"
        echo "$NEW_CONTENT" > "$TARGET_FILE"
    fi
fi

echo "操作完成，脚本将在5秒后退出..."
sleep 5
