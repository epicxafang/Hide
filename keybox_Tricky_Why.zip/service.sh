#!/system/bin/sh
MODPATH="${0%/*}"

if [ ! -x "$MODPATH/main" ]; then
    chmod +x "$MODPATH/main"
fi

exec "$MODPATH/main"